from src.common.logger_manager import get_logger
from src.chat.focus_chat.planners.actions.plugin_action import PluginAction, register_action
from typing import Tuple, Dict, Any, List
import aiohttp
import time
from bs4 import BeautifulSoup

logger = get_logger("bing_search")

@register_action
class BingSearch(PluginAction):
    """使用必应搜索引擎获取信息"""

    action_name = "bing_search"
    action_description = "执行必应搜索并通过表达器返回自然语言结果。适合需要获取最新信息、事实查询或网络资源查找的场景。"
    action_parameters = {
        "query": "搜索查询词，必选参数",
        "num_results": "返回结果数量，可选，默认值3",
        "time_range": "时间范围筛选，可选，有效值：day, week, month, year",
    }
    action_require = [
        "用户需要获取最新的网络信息",
        "用户请求进行事实性查询",
        "用户需要查找特定主题的资源"
    ]
    default = False
    associated_types = ["text"]  # 配合表达器使用

    async def process(self) -> Tuple[bool, str]:
        """执行必应搜索并通过表达器发送结果"""
        start_time = time.time()
        logger.info(f"{self.log_prefix} 开始执行搜索，参数: {self.action_data}")
        
        # 验证参数
        query = self.action_data.get("query")
        if not query:
            error_msg = "缺少必要的搜索查询词参数"
            logger.error(f"{self.log_prefix} {error_msg}")
            await self.send_message_by_expressor(error_msg)  # 用表达器发送错误提示
            return False, ""  # 结果文本留空，由表达器处理
        
        num_results = int(self.action_data.get("num_results", 3))
        time_range = self.action_data.get("time_range")
        
        try:
            logger.info(f"{self.log_prefix} 开始搜索: {query}，结果数量: {num_results}，时间范围: {time_range or '不限'}")
            results = await self._search_bing(query, num_results, time_range)
            
            if not results:
                warning_msg = "未找到相关搜索结果"
                logger.warning(f"{self.log_prefix} {warning_msg}")
                await self.send_message_by_expressor(warning_msg)  # 发送自然语言警告
                return False, ""
            
            # 用表达器发送结构化结果（需符合Bot语言风格）
            response_prompt = f"根据关键词 '{query}' 搜索到以下信息：\n"
            for i, result in enumerate(results, 1):
                response_prompt += f"{i}. {result['title']}\n   摘要：{result['snippet']}\n   链接：{result['url']}\n\n"
            
            # 使用表达器生成最终回复（LLM会自动优化语气）
            await self.send_message_by_expressor(response_prompt)
            execution_time = time.time() - start_time
            logger.info(f"{self.log_prefix} 搜索成功，通过表达器发送 {len(results)} 条结果，耗时 {execution_time:.2f} 秒")
            return True, ""  # 表达器已处理消息，此处无需返回文本
        
        except Exception as e:
            error_msg = f"搜索过程中发生错误：{str(e)}"
            logger.error(f"{self.log_prefix} {error_msg}", exc_info=True)
            await self.send_message_by_expressor("抱歉，搜索时遇到问题，请稍后再试~")  # 友好错误提示
            return False, ""
        finally:
            end_time = time.time()
            logger.info(f"{self.log_prefix} 搜索动作执行完成，总耗时: {end_time - start_time:.2f}秒")

    async def _search_bing(self, query: str, num_results: int, time_range: str = None) -> List[Dict[str, str]]:
        """发送请求并解析必应搜索结果（逻辑不变）"""
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            "Connection": "keep-alive",
        }
        
        base_url = "https://cn.bing.com/search"
        params = {"q": query, "count": num_results}
        if time_range:
            params["q"] += f" date:{time_range}"
        
        logger.info(f"{self.log_prefix} 发送HTTP请求到: {base_url}, 参数: {params}")
        
        try:
            async with aiohttp.ClientSession(headers=headers) as session:
                async with session.get(base_url, params=params) as response:
                    if response.status != 200:
                        raise Exception(f"请求失败，状态码: {response.status}")
                    html = await response.text()
                    return self._parse_search_results(html)
        except Exception as e:
            logger.error(f"{self.log_prefix} 搜索请求失败: {str(e)}")
            raise

    def _parse_search_results(self, html: str) -> List[Dict[str, str]]:
        """解析搜索结果HTML（逻辑不变）"""
        soup = BeautifulSoup(html, 'html.parser')
        results = []
        for item in soup.select(".b_algo"):
            try:
                title_elem = item.select_one("h2 a")
                if not title_elem:
                    continue
                results.append({
                    "title": title_elem.get_text(strip=True),
                    "url": title_elem.get("href", ""),
                    "snippet": item.select_one(".b_caption p").get_text(strip=True) if item.select_one(".b_caption p") else ""
                })
            except Exception as e:
                logger.warning(f"{self.log_prefix} 解析结果失败: {str(e)}")
                continue
        return results